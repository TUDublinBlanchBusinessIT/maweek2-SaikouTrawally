import {Stylesheet,Text,View } from 'react-native';

import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <View>
      <Text> Hello,World </Text>
    </View>
  );
}
